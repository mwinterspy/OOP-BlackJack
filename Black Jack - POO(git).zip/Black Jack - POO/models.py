class Player:

    def __init__(self, name: str, hand: list, points: int):
        self.name = name
        self.hand = hand
        self.point = points


class Delaer(Player):
    baralho = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13]
