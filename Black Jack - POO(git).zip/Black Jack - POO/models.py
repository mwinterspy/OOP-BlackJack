import random


class Player:

    def __init__(self, name: str, hand: list, points: int):
        self.name = name
        self.hand = hand
        self.point = points


class Delaer(Player):

    def give_card(self):
        card = random.randint(1, 13)
        return card
