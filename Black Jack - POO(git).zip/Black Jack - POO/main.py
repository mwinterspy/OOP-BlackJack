from models import Delaer, Player

player = Player("", [], 0)
dealer = Delaer("Dealer", [], 0)


def winner(player_hand: list, dealer_hand: list):
    if sum(player_hand) < 21 and sum(player_hand) > sum(dealer_hand):
        print("Congratulations " + player.name + "! You are the WINNER")
        quit()
    elif sum(player_hand) > 21 and sum(dealer_hand) > 21:
        print("It is a tie! Why don't you try again?")
        quit()
    elif sum(dealer_hand) < 21 and sum(dealer_hand) > sum(player_hand):
        print("The Dealer is the WINNER!! Why don't you try again?")
        quit()


def plays(player_hand: list, dealer_hand: list):

    opt = 1
    while (sum(player_hand) and sum(player_hand) < 21) or opt == 1 or 2:
        print("Wich of the plays you want to make?")
        print("1) Ask a card\n")
        print("2) Sum cards\n")
        print("3) Finish round\n")
        opt = int(input("Type your option: "))
        if (opt == 1):
            player_hand.append(dealer.give_card())
            dealer_hand.append(dealer.give_card())
            print(player.name + ": ", player_hand)
            print(dealer.name + ": ", dealer_hand)

        if (opt == 2):
            print(player.name + ": ", sum(player_hand))
            print("Dealer: ", sum(dealer_hand))
        if (opt == 3):
            winner(player.hand, dealer.hand)
    winner(player.hand, dealer.hand)


def first_round(player_hand: list, dealer_hand: list):
    for i in range(2):
        player_hand.append(dealer.give_card())
        dealer_hand.append(dealer.give_card())
    print(player.name + ": ", player_hand)
    print(dealer.name + ": ", dealer_hand)
    if ((sum(player_hand) > 21) or (sum(dealer_hand) > 21)):
        winner(player.hand, dealer.hand)

    plays(player.hand, dealer.hand)


def main_menu():
    print("Welcome to Black Jack\n\n")
    player.name = input("Type your name: ")
    print("\nMain menu\n\n")
    print("1) New game\n\n2)Rules\n\n3)Change name\n\n4)Quit game")
    opt = int(input("Choose an option: "))
    while opt == 2:  # Rules
        print("The rules of Black Jack are very simple")
        print("1. Both the player and the dealer start with 2 cards")
        print("2. The player then decides if he wants to get another card")
        print("3. If the player chooses to do so, the dealer does the same")
        print("4. This can continue ultil the player")
        print("decides to stop, or until the sum of all the")
        print("player's card surpass 21")
        print("5. If the player decides to stop, the dealer then can")
        print("get another card if he wishes to")
        print("6. The winner is the one whom card's sum is closest to 21")
        print("\nMain menu\n\n")
        print("1) New game\n\n2)Rules\n\n3)Change name\n\n4)Quit game")
        opt = int(input("Choose an option: "))

    while opt == 3:  # Change name
        player.name = str(input("Type your name: "))
        print("Name changed to: " + player.name)
        print("\nMain menu\n\n")
        print("1) New game\n\n2)Rules\n\n3)Change name\n\n4)Quit game")
        opt = int(input("Choose an option: "))

    if opt == 4:
        quit()

    if opt == 1:
        first_round(player.hand, dealer.hand)


input("PRESS ENTER TO CONTINUE")
main_menu()
