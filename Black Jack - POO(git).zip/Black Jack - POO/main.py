from models import Delaer, Player

game_on = True
player = Player("", [], 0)
dealer = Delaer("Dealer", [], 0)

while game_on:

    print("Welcome to Black Jack\n\n")
    player.name = input("Type your name: ")
    print("\nMain menu\n\n")
    print("1) New game\n\n2)Rules\n\n3)Change name\n\n4)Quit game")
    opt = int(input("Choose an option: "))

    while opt == 2:
        print("The rules of Black Jack are very simple")
        print("1. Both the player and the dealer start with 2 cards")
        print("2. The player then decides if he wants to get another card")
        print("3. If the player chooses to do so, the dealer does the same")
        print("4. This can continue ultil the player")
        print("decides to stop, or until the sum of all the")
        print("player's card surpass 21")
        print("5. If the player decides to stop, the dealer then can")
        print("get another card if he wishes to")
        print("6. The winner is the one whom card's sum is closest to 21")
        print("\nMain menu\n\n")
        print("1) New game\n\n2)Rules\n\n3)Change name\n\n4)Quit game")
        opt = int(input("Choose an option: "))

    while opt == 3:
        player.name = str(input("Type your name: "))
        print("Name changed to: " + player.name)
        print("\nMain menu\n\n")
        print("1) New game\n\n2)Rules\n\n3)Change name\n\n4)Quit game")
        opt = int(input("Choose an option: "))
